package com.niit.front.service;

import java.util.List;

import com.niit.front.model.Customer;

public interface CustomerService {
	
	    public List<Customer> list();
		public void addCustomer(Customer c);
		public void updteCustomer(Customer c);
		public void saveCustomer(int id);
		public boolean getCustomerById(int id);
		public boolean listCustomer();
	    
}
