package com.niit.front.DAO;

public class CustomerDAO {

}
