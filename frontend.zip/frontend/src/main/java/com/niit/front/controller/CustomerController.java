package com.niit.front.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.niit.front.model.Customer;
import com.niit.front.service.CustomerService;

@Controller
public class CustomerController {
	
	
	private CustomerService customerService;

	@Autowired(required=true)
	@Qualifier(value="customerService")
	public void setCustomerService(CustomerService cs){
		this.customerService = cs;
	}
	
	@RequestMapping(value = "/Customer", method = RequestMethod.GET)
	public String listCustomer(Model model) {
		model.addAttribute("Customer", new Customer());
		model.addAttribute("listCustomer", this.customerService.list());
		return "Customer";
	}
	
	//For add and update person both
	@RequestMapping(value= "/Customer/add", method = RequestMethod.POST)
	public String addCustomer(@ModelAttribute("Customer") Customer c){
		
		if(c.getId() == 0){
			//new person, add it
			this.customerService.addCustomer(c);
		}else{
			//existing person, call update
			this.customerService.updteCustomer(c);
		}
		
		return "redirect:/Customer";
		
	}
	
	@RequestMapping("/remove/{id}")
    public String removeCustomer(@PathVariable("id") int id){
		
        this.customerService.saveCustomer(id);
        return "redirect:/Customer";
    }
 
    @RequestMapping("/edit/{id}")
    public String editCustomer(@PathVariable("id") int id, Model model){
        model.addAttribute("Customer", this.customerService.getCustomerById(id));
        model.addAttribute("listCustomer", this.customerService.listCustomer());
        return "Customer";
    }
	
}