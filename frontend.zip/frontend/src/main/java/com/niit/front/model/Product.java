package com.niit.front.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name="Products")
public class Product {
	@Id
	@Column(name="id")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	
	
	private int productid;
	
	private String productname;
	
	

	private int productprice;

	private List<Product> productcategory;
    
	private double productcondition;
	
	private String productdescription;
	
	private String productstatus;
	
	
	
	public String getProductname() {
		return productname;
	}

	public void setProductname(String productname) {
		this.productname = productname;
	}

	public int getProductprice() {
		return productprice;
	}

	public void setProductprice(int productprice) {
		this.productprice = productprice;
	}

	public List<Product> getProductcategory() {
		return productcategory;
	}

	public void setProductcategory(List<Product> productcategory) {
		this.productcategory = productcategory;
	}

	public double getProductcondition() {
		return productcondition;
	}

	public void setProductcondition(double productcondition) {
		this.productcondition = productcondition;
	}

	public String getProductdescription() {
		return productdescription;
	}

	public void setProductdescription(String productdescription) {
		this.productdescription = productdescription;
	}

	public String getProductstatus() {
		return productstatus;
	}

	public void setProductstatus(String productstatus) {
		this.productstatus = productstatus;
	}
	@Override
	public String toString(){
		return "productid="+productid+", name="+productname+",productprice="+productprice+ ",productdescription="+productdescription+",productcategory="+productcategory+""
				+ "productcondition="+productcondition+",productstatus="+productstatus+"";
	}

}
